package com.sales.app;

import java.util.ArrayList;
import java.util.List;

import com.sales.domain.Product;
import com.sales.helper.ReadFromConsole;
import com.sales.service.InventoryService;
import com.sales.service.intf.InventoryServiceIntf;

public class InventoryApp {
	
	List<Product> productList = new ArrayList<Product>();

	public static void main(String[] args) {
		
		InventoryApp ivtApp = new InventoryApp();
		int choice=0;
		int prodId;
		String prodName;
		double price;
		int qty;
		String mfName;
		
		InventoryServiceIntf inventoryService = new InventoryService();
		
		do {
			showMenu();
			choice=ReadFromConsole.readInt("Enter your choice[1-4]: ");
			switch(choice) {
			case 1:
				prodId=ReadFromConsole.readInt("Product id:");
				prodName=ReadFromConsole.readString("Product name:");
				mfName=ReadFromConsole.readString("Manufacturer name:");
				price=ReadFromConsole.readDouble("Product Price:");
				qty=ReadFromConsole.readInt("Product Qty");
				Product prod=new Product(prodId, prodName, price, qty, mfName);
				inventoryService.addInventory(ivtApp.productList, prod);
				break;
				
			case 2:
				prodId=ReadFromConsole.readInt("Product id to search for:");
				Product result = inventoryService.searchForProductId(ivtApp.productList, prodId);
				if(result!=null)
					inventoryService.showAProduct(result);
				else
					System.out.println("The given product id is not found in the inventory");
				break;
				
			case 3:
				inventoryService.showAllProducts(ivtApp.productList);
				
			default:
				break;
			}

			
		} while (choice!=4);
	}

	private static void showMenu() {
		// TODO Auto-generated method stub
		System.out.println("1. Add product to inventory");
		System.out.println("2. Search a product");
		System.out.println("3. Show all products");
		System.out.println("4. Exit");
		
	}
}
