package com.sales.service.intf;

import java.util.List;

import com.sales.domain.Product;

public interface InventoryServiceIntf {

	public Product addInventory(List<Product> list,Product prod);
	public void showAProduct(Product prod);
	public void showAllProducts(List<Product> list);
	public Product searchForProductId(List<Product> list,int prodId);
}
