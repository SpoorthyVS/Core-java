package com.sales.service;

import java.util.Iterator;
import java.util.List;

import com.sales.domain.Product;
import com.sales.service.intf.InventoryServiceIntf;

public class InventoryService implements InventoryServiceIntf{
	
	public Product addInventory(List<Product> list,Product prod) {
			list.add(prod);
			return prod;
	}
		
		
	
	public void showAProduct(Product prod) {
		System.out.println("Product Id: "+ prod.getId());
		System.out.println("Product name: "+ prod.getProductName());
		System.out.println("Manufacture's name: "+prod.getMfName());
		System.out.println("Product price: "+prod.getPrice());
		System.out.println("In Stock: "+prod.getQty());
		System.out.println("Stock value of the product: "+prod.getStockValue());
		
	}
	
	public void showAllProducts(List<Product> list) {
		if(list.isEmpty()) {
			System.out.println("There are no products in the store");
		}
		else if(list.size()>0) {
			Iterator<Product> iterator=list.iterator();
			while(iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}
		

}
	
	public Product searchForProductId(List<Product> list,int prodId) {
		Product prod=null;
		
		if(list.size()>0) {
			Iterator<Product> iterator = list.iterator();
			while(iterator.hasNext()) {
				prod=iterator.next();
				if(prod.getId()==prodId)
					return prod;
			}
		}
			
		return prod;
	}

		
}

	
	
		
		

