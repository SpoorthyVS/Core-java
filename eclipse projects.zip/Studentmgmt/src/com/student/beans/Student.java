package com.student.beans;

public class Student {

	int studentId;
	String studentName;
	String sub1;
	String sub2;
	String sub3;
	double marks1;
	double marks2;
	double marks3;
	
	
	
	
	
	
	public Student(int studentId, String studentName, String sub1, String sub2, String sub3, double marks1,
			double marks2, double marks3) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.sub1 = sub1;
		this.sub2 = sub2;
		this.sub3 = sub3;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
	}
	
	
	/*public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSub1() {
		return sub1;
	}
	public void setSub1(String sub1) {
		this.sub1 = sub1;
	}
	public String getSub2() {
		return sub2;
	}
	public void setSub2(String sub2) {
		this.sub2 = sub2;
	}
	public String getSub3() {
		return sub3;
	}
	public void setSub3(String sub3) {
		this.sub3 = sub3;
	}
	public double getMarks1() {
		return marks1;
	}
	public void setMarks1(double marks1) {
		this.marks1 = marks1;
	}
	public double getMarks2() {
		return marks2;
	}
	public void setMarks2(double marks2) {
		this.marks2 = marks2;
	}
	public double getMarks3() {
		return marks3;
	}
	public void setMarks3(double marks3) {
		this.marks3 = marks3;
	}*/
	
	public double totalMarks() {
		
		return marks1+marks2+marks3;
	}
	
	public double avgMarks(){
		return (marks1+marks2+marks3)/3;
	}
	
	public char grades() {
		if(avgMarks()>75)
			return 'A';
		else if(avgMarks() >45)
			return 'B';
		else if(avgMarks() <45)
			return 'C';
		return 0;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", sub1=" + sub1 + ", sub2=" + sub2
				+ ", sub3=" + sub3 + ", marks1=" + marks1 + ", marks2=" + marks2 + ", marks3=" + marks3 + ", Total marks="+ totalMarks()+ ", Average Marks="+ avgMarks()+"]";
	}
	
	
}
