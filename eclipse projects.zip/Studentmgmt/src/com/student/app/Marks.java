package com.student.app;

import com.student.beans.Student;

public class Marks {

	public static void main(String[] args) {
		
	    Student stu=new Student(78, "Hrishi", "java", "aws", "sql", 8, 19, 42);
	   
	    /*stu.setStudentId(56);
		stu.setStudentName("Sachin");
		stu.setSub1("Maths");
		stu.setSub2("Science");
		stu.setSub3("Kannada");
		stu.setMarks1(77);
		stu.setMarks2(87);
		stu.setMarks3(99);
		
		
		System.out.println("Student Id: " + stu.getStudentId());
		System.out.println("Student Name: " + stu.getStudentName());
		System.out.println("Subject 1: " + stu.getSub1());
		System.out.println("Subject 2: " + stu.getSub2());
		System.out.println("Subject 3: " + stu.getSub3());
		System.out.println("Marks 1: " + stu.getMarks1());
		System.out.println("Marks 2: " + stu.getMarks2());
		System.out.println("Marks 3: " + stu.getMarks3());
		
		System.out.println("Total Marks: "+ stu.totalMarks());
		System.out.println("Average Marks: "+ stu.avgMarks());
		System.out.println("Grades: " + stu.grades());
		System.out.println(stu.toString()); */
	
	    
	;
	System.out.println("Total marks: "+ stu.totalMarks());
	}


	


	
	
}
