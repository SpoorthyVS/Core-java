
public class Employee extends Person {

	String compName;
	String location;
	
	
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Employee(int id,String name,int age, String job,String compName, String location) {
		super(id ,name,age,job,compName);
		this.compName = compName;
		this.location = location;
	}


	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
}
