package com.bank.app;

import com.bank.beans.Account;
import com.bank.beans.Address;
import com.bank.beans.Customer;
import com.bank.beans.Transaction;
import com.bank.helper.ReadFromConsole;
import com.bank.service.BankingServiceImpl;
import com.bank.service.intf.BankingServiceIntf;

public class BankingApp {

	public static void main(String[] args) {
		
		Account accounts[]=new Account[10];
		Transaction transactions[]=new Transaction[50];
		Customer customers[]=new Customer[10];
		
		int choice=0;
		int custId;
		int acctId;
		String custName;
		String street;
		String city;
		String state;
		String acctType;
		double amount;
		double withDrawLimit;
		String email;
		String panNum;
		String pinCode;
		int i =Customer.getCount();
		int acctCount=Account.getCount();
		Account acct= null;
		BankingServiceIntf bankService=new BankingServiceImpl();
		double balance;
		
		do {
			showMenu();
			choice =ReadFromConsole.readInt("Enter Your Choice");
			
			switch(choice) {
			
			case 1:
				if(i<10) {
				custId=ReadFromConsole.readInt("Enter Customer Id");
				custName=ReadFromConsole.readString("Enter Customer Name");
				email=ReadFromConsole.readString("Enter Your Email");
				panNum=ReadFromConsole.readString("Enter pan number");
				street=ReadFromConsole.readString("Enter Street name");
				city=ReadFromConsole.readString("Enter city name");
				state=ReadFromConsole.readString("Enter state name");
				pinCode=ReadFromConsole.readString("Enter Pin code");
				Address addr =new Address(street, city, state,pinCode);
				customers[i++]= new Customer(custId, custName, addr, email,panNum); 
			} else
				System.out.println("Customer Array is out of space");
			break;
				
		case 2:
			if(acctCount<10) {
					
				acctId=ReadFromConsole.readInt("Enter account id: ");
				acctType=ReadFromConsole.readString(" Enter Type of Account: saving/Current");
				amount=ReadFromConsole.readDouble("Enter the amount of initial deposite: ");
				withDrawLimit=ReadFromConsole.readDouble("Enter withdraw limit: ");
				custId=ReadFromConsole.readInt("Enter customer id ");
				int found=bankService.searchForCustomer(customers, custId);
				if(found>0) {
					acct=bankService.openAccount(customers[found],acctId,acctType,amount,withDrawLimit,accounts,transactions);
					if(acct!=null) {
						System.out.println("Accoutn created successfully for the customer:" + custId);
					}
						else
							System.out.println("Account creation failed");
					}
					else 
						System.out.println("Customer record not fount for the customer id: "+custId);
			}else
				System.out.println("Account array is out of space");
		
		case 3:
			acctId=ReadFromConsole.readInt("Enter the accountk Id: ");
			amount=ReadFromConsole.readDouble("Enter the amount to the deposit: ");
			balance=bankService.deposit(acctId,amount,accounts,transactions);
			if(balance<0)
				System.out.println("Account Id not found");
			else
				System.out.println("Current balance after the deposit: "+ balance);
			break;
		case 4:
			acctId=ReadFromConsole.readInt("Enter the account Id: ");
			amount=ReadFromConsole.readDouble("Enter the amount to the withdraw: ");
			balance=bankService.withdraw(acctId,amount,accounts,transactions);
			if(balance<0)
				System.out.println("Account Id not found");
			else
				System.out.println("Current balance after the withdraw: "+ balance);
			break;
		case 5:
			 bankService.showCustomers( customers);
			break;
		case 6:
			 bankService.showAccounts(accounts);
			break;
		case 7:
			 bankService.showTransactions(transactions) ;

			break;
				
		default:
			break;
			}
		
		}while(choice !=8);
	}

	private static void showMenu() {
		// TODO Auto-generated method stub
		System.out.println("1.Register Customer");
		System.out.println("2.Open Account");
		System.out.println("3.Deposit");
		System.out.println("4.WithDraw");
		System.out.println("5.Show Customers");
		System.out.println("6.Show Accounts");
		System.out.println("7.Show Transactions");
		System.out.println("8.Exit");
	}
}
