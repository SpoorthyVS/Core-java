package com.bank.beans;

import javax.naming.InsufficientResourcesException;

import com.bank.exception.InsufficientFundException;

public class Account {
	
	private static int acctCount=0;
	int acctId;
	int cusId;
	String acctHolderName;
	String acctType;
	double balance;
	double withDrawLimit;
	
	
	
	@Override
	public String toString() {
		return acctId+"," +
	    cusId + "," +
	    acctHolderName+"," +
		 acctType + "," +
		 balance + "," +
		 withDrawLimit;
	}

	public static int getCount() {
		
		return acctCount;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
		
		if(acctCount<10)
		acctCount++;
	}
	
	
	public Account(int acctId, int cusId, String acctHolderName, String acctType, double balance,
			double withDrawLimit) {
		super();
		this.acctId = acctId;
		this.cusId = cusId;
		this.acctHolderName = acctHolderName;
		this.acctType = acctType;
		this.balance = balance;
		this.withDrawLimit = withDrawLimit;
		if(acctCount<10)
			acctCount++;
	}
	
	
	public int getAcctId() {
		return acctId;
	}
	public void setAcctId(int acctId) {
		this.acctId = acctId;
	}
	public int getCusId() {
		return cusId;
	}
	public void setCusId(int cusId) {
		this.cusId = cusId;
	}
	public String getAcctHolderName() {
		return acctHolderName;
	}
	public void setAcctHolderName(String acctHolderName) {
		this.acctHolderName = acctHolderName;
	}
	public String getAcctType() {
		return acctType;
	}
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getWithDrawLimit() {
		return withDrawLimit;
	}
	public void setWithDrawLimit(double withDrawLimit) {
		this.withDrawLimit = withDrawLimit;
	}
	
	public double deposite(double amount) {
		this.balance=this.balance+amount;
		return getBalance();
	}
	
	public double withdraw(double amount) throws InsufficientFundException {
		
		double permittedAmount=balance;
		if(acctType.equalsIgnoreCase("savings"))
			permittedAmount=permittedAmount-withDrawLimit;
		else
			permittedAmount=permittedAmount-withDrawLimit;
		if(amount > permittedAmount)
			throw new InsufficientFundException("Insufficient Balance in your account");
		else
			balance=balance-amount;
		return balance;
	}
	
}
