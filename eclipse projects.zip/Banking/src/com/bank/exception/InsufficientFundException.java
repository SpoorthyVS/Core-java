package com.bank.exception;

public class InsufficientFundException extends Exception {

	public InsufficientFundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientFundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InsufficientFundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InsufficientFundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InsufficientFundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
