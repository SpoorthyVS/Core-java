import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;

public class PreparedStatementExample {

	public static void main(String[] args) {
        try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","admin");
			
			PreparedStatement ps=con.prepareStatement("select first_name,last_name,salary from employees where department_id=? and UPPER(job_id)=UPPER(?)");
			System.out.println("Enter department no: ");
			int depId=new Scanner(System.in).nextInt();
			System.out.println("Enter job id: ");
			String jobid=new Scanner(System.in).next();
			ps.setInt(1, depId);
			ps.setString(2, jobid);
			
			ResultSet rs=ps.executeQuery();
			
			ResultSetMetaData rsmd=rs.getMetaData();
			System.out.println(rsmd.getColumnCount());
			System.out.println(rsmd.getColumnName(3));
			while(rs.next()) {
				System.out.println(rs.getString(1)+","+rs.getString(2)+","+rs.getDouble(3));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
