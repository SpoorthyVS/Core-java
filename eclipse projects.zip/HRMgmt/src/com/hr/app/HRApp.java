package com.hr.app;

import com.hr.beans.Employee;

public class HRApp {
	
	public static void main(String[] args) {
		
		Employee emp=new Employee();
		emp.setEmpId(100);
		emp.setFirstName("Steve");
		emp.setLastName("Mark");
		emp.setBasicSalary(2000000.00);
		emp.setDeductions(455555.00);
		emp.setAllowances(20000);
		
		emp.getEmpId();
		emp.getFirstName();
		emp.getLastName();
		emp.getBasicSalary();
		emp.getDeductions();
		emp.getAllowances();
		
		
		System.out.println("Employee ID:" +emp.getEmpId());
		System.out.println("Employee FIRST NAME:" +emp.getFirstName());
		System.out.println("Employee LAST NAME:" +emp.getLastName());
		System.out.println("Employee BASIC SALARY:" +emp.getBasicSalary());
		System.out.println("Employee DEDUCTIONS:" +emp.getDeductions());
		System.out.println("Employee ALLOWANCES:" +emp.getAllowances());
		System.out.println("Net SALARY:" + emp.getNetSalary());
	
	}
}
