package com.sales.service;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.sales.domain.Product;
import com.sales.service.intf.InventoryServiceJDBCIntf;

public class InventoryJDBCService implements InventoryServiceJDBCIntf{
	
	public Product addInventory(Connection con,Product prod) 
    {
        try {
            PreparedStatement ps = con.prepareStatement("insert into products values(?,?,?,?,?,)");
            ps.setInt(1, prod.getId());
            ps.setString(2, prod.getProductName());
            ps.setString(3, prod.getMfName());
            ps.setDouble(4,  prod.getPrice());
            ps.setInt(5,  prod.getQty());

            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prod;
    }

    public void showAProduct(Product prod)
    {
        System.out.println("Product Id:"+prod.getId());
        System.out.println("Product Name:"+prod.getProductName());
        System.out.println("Manufactures name:"+prod.getMfName());
        System.out.println("Product price:"+prod.getPrice());
        System.out.println("In stock:"+prod.getQty());
        System.out.println("Stock value of product:"+prod.getStockValue());

    }

    public void showAllProducts(Connection con)
    {
        try {
            PreparedStatement ps = con.prepareStatement("select * from products");
            ResultSet rs = ps.executeQuery();
            System.out.format("%15s%30s%20s%10s%6s","Productid: ","Product Name","Manufacturer Name","Price","Quantity");
            while(rs.next())
            {
                System.out.format("%15s%30s%20s%10.2%6d",rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5));

            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public Product searchForProductId(Connection con, int prodId)
    {
    	Product prod=null;

        try {
            PreparedStatement ps=con.prepareStatement("select * from products where prod_id+?");
            ps.setInt(1, prodId);
             ResultSet rs=ps.executeQuery();
             if(rs.next())
                 {
                     prod=new Product();
                     prod.setId(rs.getInt(1));
                     prod.setProductName(rs.getString(2));
                     prod.setMfName(rs.getString(3));
                     prod.setPrice(rs.getDouble(4));
                     prod.setQty(rs.getInt(5));

                 }
                 rs.close();
                 ps.close();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return prod;
        }
      

    public Product updateProductUsingId(Connection con,int prodId,int qty,double price)
    {
    	try {
			Product prod=null;
			PreparedStatement ps=con.prepareStatement("update products set price=?,"+ " quantity=? where prod_id=?");
			ps.setDouble(1, price);
			ps.setInt(2, qty);
			ps.setInt(3, prodId);
			
			
			ps.executeUpdate();
			prod=searchForProductId(con, prodId);
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
        return null;
    }

    public int deleteProduct(Connection con,int prodId)
    {
    	int result=0;
    	try {
			
			PreparedStatement ps=con.prepareStatement("Delete from products where prod_id=?");
			ps.setInt(1, prodId);
			ps.executeUpdate();
			ps.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return result;
    }

	

	
		
}

	
	
		
		

