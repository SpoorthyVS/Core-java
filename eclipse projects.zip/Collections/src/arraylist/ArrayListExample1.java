package arraylist;
import java.util.ArrayList;
public class ArrayListExample1 {
   public static void main(String[] args) {
      ArrayList<String> names = new ArrayList<String>();
      names.add("ram");
      names.add("Thomas");
      names.add("Arjun");
      names.add("Christy");
      names.set(0, "Surya");
      names.set(0, "Mary");
      
      
      System.out.println(names);
   }
}