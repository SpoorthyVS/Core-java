
public class Test {
	static int x=20;
	static {
		System.out.println("Inside static code block ");
		System.out.println(x);
	}
	
	public void print() {
		System.out.println("Inside print method");
	}
	
	public static void main(String[] args) {
		printx();
		Test t = new Test();
		t.print();
		System.out.println(t.i);
	}
	
	int i=10;
	
	
	public static void printx() {
		System.out.println(x);
	}
}
