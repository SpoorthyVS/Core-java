import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class ReadFromWebSite {
	
	public static void main(String[] args) {
		try {
		URL url=new URL("https://www.google.com/");
		URLConnection uc=url.openConnection();
		uc.connect();
		
		BufferedReader br=new BufferedReader(new InputStreamReader(uc.getInputStream()));
		String s=br.readLine();
		int i=0;
		while(s!=null) {
			System.out.println(i++ +" "+s);
			s=br.readLine();
		}
		br.close();
		
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
