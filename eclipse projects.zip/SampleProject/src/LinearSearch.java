
public class LinearSearch {

	public static void main(String[] args) {
		
		int[] numbers = {2,4,68,9,5,95};
		printArray(numbers);
		
		int result=linearSearch(numbers, 7);
		if(result>=0)
			System.out.println("The value is found at index:" +result);
		else
			System.out.println("The value is not found in the array");
		
		System.out.println("List of values in numbers array");
		for(int i=0;i<numbers.length;i++) {
			System.out.println(numbers[i]);
		}
		int foundAtIndex= -1;
		for(int i=0;i<numbers.length;i++) 
			if(numbers[i]==5) {
				foundAtIndex=i;
				break;
			}
		if(foundAtIndex>=0) 
			System.out.println("The value is found at index: "+ foundAtIndex);
		else
				System.out.println("The value is not found in the array");
		}
	
	public static void printArray(int[] arrayOfNumber) {
		System.out.println("List of values in numbers array");
		for(int i=0;i<arrayOfNumber.length;i++) {
			System.out.println(arrayOfNumber[i]);
		}
	}
	
	public static int linearSearch(int[] arrayOfNumber,int searchVal) {
		for(int i=0;i<arrayOfNumber.length;i++)
			if(arrayOfNumber[i]==55)
				return i;
		return -1;
	} 
	


}

