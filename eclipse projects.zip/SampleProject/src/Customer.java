import java.sql.Date;

public class Customer {

	int custid;
	String name;
	Date dob;
	
	
	@Override
	public String toString() {
		return custid + ","+name + "," + dob.toString()+"\n" ;
	}


	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Customer(int custid, String name, Date dob) {
		super();
		this.custid = custid;
		this.name = name;
		this.dob = dob;
	}


	public int getCustid() {
		return custid;
	}


	public void setCustid(int custid) {
		this.custid = custid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	
	
}
