
public class Child extends Parent {

	String childName;
	City childCity;
	

	public Child() {
		super();
		
		System.out.println("Child default constructor called");
	}


	public Child(String parentName,String childName) {
		super(parentName);
		this.childName = childName;
		//this.parentName = parentName;
		System.out.println("Child  class constructor called with parameter");

	}


	public String getChildName() {
		return childName;
	}


	public void setChildName(String childName) {
		this.childName = childName;
	}

	
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "Parent Name: " + parentName + "," + "Child Name: " + childName;
		}


		public City getChildCity() {
			return childCity;
		}


		public void setChildCity(City childCity) {
			this.childCity = childCity;
		}
	
	
}
