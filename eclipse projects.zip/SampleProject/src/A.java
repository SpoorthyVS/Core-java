
public class A {
	
//	private static int count=0;
	private int age;
	private String name;
	
	
//	public static int getCount() {
//		return count;
//	}
//	

	public A(int a, String n) {
		//count++;
		System.out.println("Constructor with args");
		age=a;
		name=n;
	}
	
	
	public A() {
		this(24,"George");
		//count++;
		System.out.println("Default Constructor");
	}
	
	
	public void assignAge(int age) {
		this.age=age;

	}
	
	public void assignName() {
		name="Mike";
	}
	
	public int readAge() {
		return age;
	}
	
	public String readname() {
		return name;
	}
	
}
