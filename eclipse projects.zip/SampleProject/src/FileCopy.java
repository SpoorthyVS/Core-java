import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class FileCopy {

	public static void main(String[] args) {
		FileReader fr=null;
		BufferedReader br=null;
		FileWriter fw=null;
		BufferedWriter bw=null;
		
		try {
			
			fr=new FileReader("input.txt");
			br=new BufferedReader(fr);
			fw=new FileWriter("Output.txt");
			bw=new BufferedWriter(fw);
			
			String s=br.readLine();
			while(s!=null) {
				bw.write(s+"\n");
				bw.flush();
				s=br.readLine();
			}
			bw.close();
			br.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
