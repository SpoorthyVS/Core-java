
public class TestInheritence {

	public static void main(String[] args) {
		Child child = new Child();
		
		System.out.println("Parent:"+child.getParentName()+ "Child name:"+child.getChildName());
		Child child1=new Child("parent", "child");
		System.out.println("Parent: "+child1.getParentName()+ " Child name: "+child1.getChildName());

		String childName="Mike";
		String parentName="Tyson";
		
		System.out.println(childName);
		child.setChildName(childName);
		child.setParentName(parentName);
		childName="Ronaldo";
		System.out.println(childName);
		
		System.out.println("Parent: "+child.getParentName()+ " Child name: "+child.getChildName());
		
		System.out.println(child);
		
		Parent parent = new Parent();
		parent.setParentName("Tulasi");
		System.out.println(parent);
		
		City parentCity=new City("Banglore");
		child.setParentCity(parentCity);
		child.setChildCity(new City("Mumbai"));
		System.out.println("Parent City: "+ child.getParentCity().getCityName()+ "Child City: " + child.getChildCity().getCityName());
	}
	
}