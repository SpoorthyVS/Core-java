package Inheritance;

public class Base {
	
	int id;
	String name;
	Address address;
	
	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Base() {
		
	}

	public Base(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public Base(int id) {
		this.id=id;
		this.name="Hello";
	}
	
	
	public Base(String name) {
		this.name=name;
		this.name="Hello";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
