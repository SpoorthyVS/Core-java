package Inheritance;

public class Address {

	String streetName;
	String cityName;
	String state;
	String pincode;
	
	
	public Address() {
		super();
		
	}
	
	
	public Address(String streetName, String cityName, String state, String pincode) {
		super();
		this.streetName = streetName;
		this.cityName = cityName;
		this.state = state;
		this.pincode = pincode;
	}
	
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}


	@Override
	public String toString() {
		return "Address [streetName=" + streetName + ", cityName=" + cityName + ", state=" + state + ", pincode="
				+ pincode + "]";
	}
	
	
	
	
}
