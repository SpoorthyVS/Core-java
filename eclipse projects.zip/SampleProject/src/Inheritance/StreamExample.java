package Inheritance;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class StreamExample {

	public static void main(String[] args) {
		
		InputStream is = System.in;
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		OutputStream os=System.out;
		OutputStreamWriter osr=new OutputStreamWriter(os);
		BufferedWriter bw=new BufferedWriter(osr);
		
		try {
			String s=br.readLine();
			while(s!=null) {
				bw.write("value of s: "+s);
				//bw.flush();
				
				s=br.readLine();
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
