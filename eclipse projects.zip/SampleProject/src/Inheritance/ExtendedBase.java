package Inheritance;

public class ExtendedBase extends Base {

	int age;
	String email;
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public ExtendedBase(int id, String name, int age, String email,Address add) {
		this.address=add;
		this.name = name;
		this.id = id;
		this.age = age;
		this.email = email;
		
	}
	
	public ExtendedBase(int id, String name, int age, String email,String streeName,String cityName,String state,String pincode) {
		this.address=new Address();
		this.name = name;
		this.id = id;
		this.age = age;
		this.email = email;
		
	}
	
	
	@Override
	public String toString() {
		return id+","+name+","+age+","+email;
	}
	
}
