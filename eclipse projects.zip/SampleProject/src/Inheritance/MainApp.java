package Inheritance;

public class MainApp {

	public static void main(String[] args) {
		
		Address add=new Address("M.G.Road","Blr","KA","560001");

		ExtendedBase eb = new ExtendedBase(101, "Raju", 22, "raju@gmail.com",add);
		
		ExtendedBase eb1 = new ExtendedBase(102, "Ram", 22, "ram@gmail.com", "M.G.Road","Blr","KA","560001");

		/*eb.setId(100);
		eb.setName("Raj");
		eb.setAge(25);
		eb.setEmail("raj@gmail.com");*/
		
	
		//System.out.println("Id:"+ eb.getId()  + "  Name:"+ eb.getName() + "  Age:" + eb.getAge() + "  Email:" + eb.getEmail());
		System.out.println(eb);
		System.out.println(add);
		System.out.println(eb+","+eb.getAddress());
		System.out.println(eb1+"Address"+eb1.getAddress());
	}
}
