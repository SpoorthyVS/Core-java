import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Scanner;

public class SaveCustomer {

	public static void main(String[] args) {
		boolean isContinue=true;
		FileWriter fw=null;
		PrintWriter pw=null;
		Scanner scan=new Scanner(System.in);
		
		do {
		try {
			
			fw=new FileWriter("CustomerData.txt");
			pw=new PrintWriter(fw);
			
			System.out.println("Customer Id: ");
			int custId=scan.nextInt();
			System.out.println("Customer name: ");
			String name=scan.next();
			System.out.println("Customer Date of Birth");
			Date dob=Date.valueOf(scan.next());
			
			Customer cust=new Customer(custId,name,dob);
			pw.write(cust.toString());
			pw.flush();
			System.out.println("Do you like to continue");
			isContinue=scan.nextBoolean();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}while(isContinue);
		
	}
}
