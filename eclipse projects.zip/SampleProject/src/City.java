
public class City {

	String cityName;

	public City() {
		super();
		// TODO Auto-generated constructor stub
	}

	public City(String cityName) {
		super();
		//this.cityName = cityName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	
	
}
