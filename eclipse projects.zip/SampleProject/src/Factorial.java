
public class Factorial {

	public static void main(String[] args) {
		
		if(args.length<1) {
			System.out.println("Add line of arguments");
		}
		
		for(int j=0;j<args.length;j++) 
		{
		int number=Integer.parseInt(args[j]);
		int factor=1;
		
		for(int i=1;i<=number;i++) {
			factor = factor*i;
		}
			System.out.println("factorial of " + number + " is:" + factor);
		}
  }
}

