
public class B {

	public static void main(String[] args) {
		
		A a=new A();
//		A a1=new A();
//		A a2=new A();
//		A a3=new A();
//		A a4=new A();
		
		a.assignAge(43);
		System.out.println(a.readAge()+"Count:");//+A.getCount());
	}
}
