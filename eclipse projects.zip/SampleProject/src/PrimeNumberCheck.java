
public class PrimeNumberCheck {

	public static void main(String[] args) {
		
//		if(args.length<1) {
//			System.out.println("There are no command line arguments");
//			System.out.println("Useage : Java PrimeNumberCheck <num> <num2>....");
//			System.exit(1);
//		}
//		
//		for(int j=0;j<args.length;j++) {
		int number = 4;//Integer.parseInt(args[j]);
		boolean isPrime=true;
		
		for(int i=2;i<=number/2;i++) { 
			if(number%i==0) {
				isPrime=false;
				break;
			}
		}
		
		if(isPrime)
			System.out.println("The Number :" +number+" is a Prime Number");
		else
			System.out.println("The Number :" +number+" is not a Prime Number");
	}
}
	

	
	
