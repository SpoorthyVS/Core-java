import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderExample {

	public static void main(String[] args) {
		
		
		FileReader fr=null;
		BufferedReader br=null;
		try {
			
			fr=new FileReader("input.txt");
			br=new BufferedReader(fr);
			String s=br.readLine();
			while(s !=null) {
				System.out.println(s);
				s=br.readLine();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		finally {
			try {
				if(fr!=null)
					fr.close();
				if(br!=null)
					fr.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
