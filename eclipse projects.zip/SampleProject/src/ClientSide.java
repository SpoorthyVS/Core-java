import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientSide {

	  public static void main(String[] args) {
	        // TODO Auto-generated method stub

	 

	        if(args.length!=3)
	        {
	            System.out.println("Command needs three arguments : hostname,portno and msg");
	            System.exit(0);
	        }

	        String serverName=args[0];
	        int portNo=Integer.parseInt(args[1]);

	        try {
	            Socket client=new Socket(InetAddress.getByName(serverName),portNo);

	            DataOutputStream dos= new DataOutputStream(client.getOutputStream());

	            dos.writeUTF(args[2]);
	        } catch (UnknownHostException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }


	  }


}
