
import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSide {

	   public static void main(String[] args) {

	        // TODO Auto-generated method stub

	        try {

	            ServerSocket s=new ServerSocket(1225);
	            System.out.println("Server Listening at host:"+s.getInetAddress().getHostName()+" on port: "+s.getLocalPort());

	            

	            while(true)

	            {

	                Socket s1=s.accept();

	                DataInputStream d=new DataInputStream(s1.getInputStream());

	                String data=d.readUTF();

	                System.out.println("Data received "+data);

	            }

	        } catch (IOException e) {

	            // TODO Auto-generated catch block

	            e.printStackTrace();

	        }

	    }


}
