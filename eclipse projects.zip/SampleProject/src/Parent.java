
public class Parent {

	String parentName;
	City parentCity;
	
	public Parent() {
		super();
		System.out.println("Parent default constructor called");

	}

	public Parent(String parentName) {
		super();
		this.parentName = parentName;
		System.out.println("Parent class constructor called with parameter");

	}

	
	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Parent Name: " + parentName ;
	}

	public City getParentCity() {
		return parentCity;
	}

	public void setParentCity(City parentCity) {
		this.parentCity = parentCity;
	}
	
	
	
}
