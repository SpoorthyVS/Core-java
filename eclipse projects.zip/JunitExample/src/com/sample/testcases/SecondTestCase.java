package com.sample.testcases;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class SecondTestCase {

	@BeforeClass
	public static void init() {
		System.out.println("init method called");
	}
	
	@Before
	public void before() {
		System.out.println("in before method");
	}
	
	@After
	public void after() {
		System.out.println("in after method");
	}
	
	@Test
	public void test1() {
		System.out.println("test 1 method is called");
	}
	
	@Test
	public void test2() {
		System.out.println("test 2 method is called");
	}
	
	@AfterClass
	public static void afterClass() {
		System.out.println("After method is called");
	}
}
