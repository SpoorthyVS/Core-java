package com.sample.testcases;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import junit.framework.TestCase;

public class FirstTestCase extends TestCase {

	
	protected void setUp() throws Exception {
		System.out.println("inside setup method");
		
	}
	
	protected void tearDown() throws Exception{
		System.out.println("inside tear down method");
	}
	
	public void testaddNumbers() {
		System.out.println("add number called");
		int a=10;
		int b=20;
		assertEquals(30,a+b);
	}
	
}
