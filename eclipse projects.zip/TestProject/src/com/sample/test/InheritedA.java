package com.sample.test;

import com.sample.A;

public class InheritedA extends A {

}
