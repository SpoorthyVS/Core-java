package com.sample;

public class B {

	A a=null;

	public A getA() {
		System.out.println(a.name);
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}
	
	
}
