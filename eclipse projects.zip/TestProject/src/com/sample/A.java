package com.sample;

public class A {

	 int a=10;
	 String name ="Welcome";
	
}
