package com.sample;

public class C {

	public static void main(String[] args) {
		
		B b=new B();
		b.setA(new A());
		System.out.println(b.a.name);
		System.out.println(b.getA().name);
	}
}
