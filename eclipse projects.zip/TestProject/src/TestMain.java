
public class TestMain {

	int x=23;
	String name="Hello";
	Address addr=null;
	
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	
	public static void main(String[] args) {
		
		TestMain testMain = new TestMain();
		Address addr=new Address();
		testMain.setAddr(addr);//!
		System.out.println("Addr value: "+ addr + "TestMain.addr: "+testMain.getAddr());
		addr.setCityName("West banglore");
		//addr=null; //!!
		//testMain.getAddr().setCityName("Banglore");
		testMain.getAddr().setStreetName("M.G.Road");
		testMain.getAddr().setState("KA");
		
		System.out.println("Value of x: "+ testMain.x);
		System.out.println("Value if Name: "+ testMain.name);
		System.out.println("Address: "+testMain.getAddr().getStreetName()+","+testMain.getAddr().getCityName()+","+testMain.getAddr().getState());
		//we are getting the address even though we have assigned addr as null(!!) because we have copied inside the testMain before assigning the value(!)
	
		// if we comment down the testMain.setAddr(addr);(!) then we get an exception of null pointer exception
	}
}
