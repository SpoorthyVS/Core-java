
public class TestServiceImple2 implements TestService {

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		System.out.println(name);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "TestSeviceImple2"+this.getClass().getName();
	}

}
