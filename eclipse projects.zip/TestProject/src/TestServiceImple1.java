
public class TestServiceImple1 implements TestService {

	int number;
	String text;

	
	@Override
	public String getName() {
		
		return text + this.getClass().getName();
	}
	
	@Override
	public void setName(String name) {
		
		this.text=name;
	}
	
	
	
	
}
