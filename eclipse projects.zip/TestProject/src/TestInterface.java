
public class TestInterface {

	public static void main(String[] args) {
		
		TestService test=new TestServiceImple1();
		TestService test1=new TestServiceImple2();
		
		test.setName("Hello");
		System.out.println(test.getName());
		test1.setName("Welcome");
		System.out.println(test1.getName());
	}
}
