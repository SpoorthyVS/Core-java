package com.bank.service;

import java.sql.Timestamp;

import com.bank.beans.Account;
import com.bank.beans.Customer;
import com.bank.beans.Transaction;
import com.bank.service.intf.BankingServiceIntf;

public class BankingServiceImpl implements BankingServiceIntf {

	public Account openAccount(Customer cust, int acctId,String acctType,double amount,double withDrawLimit,Account[] accts,Transaction[] transactions) {
		
		
		int transcount=Transaction.getCount();
		if(transcount<50)
			{
			accts [Account.getCount()] = new Account(acctId,cust.getCustId(),acctType,cust.getCustName(),amount,withDrawLimit);
			transactions [transcount]=new Transaction(new Timestamp(System.currentTimeMillis()),"New account", acctId,amount);
			return accts[Account.getCount()-1];

			}
		return null;
	}
	
	public int searchForAccount(Account[] accounts,int acctId) {
		for(int i=0;i<accounts.length&& accounts[i]!=null;i++){
			if(accounts[i].getAcctId()==acctId)
				return i;
		}
		return -1;
	}
	
	
	public double withdraw(int acctId,double amount,Account[] accts,Transaction[] transactions) {
		int index=searchForAccount(accts,acctId);
			double currentBalance=0;
		if(index>=0) {
			if(Transaction.getCount()<50) {
			currentBalance=accts[index].deposite(amount);
			transactions[Transaction.getCount()]=new Transaction(new Timestamp(System.currentTimeMillis()),"debit",acctId,amount);
			
			}
			currentBalance=-1.0d;
		}
		return currentBalance;
	}
	
	public double deposit(int acctId, double amount,Account[] accts,Transaction[] transactions) {
		int index=searchForAccount(accts,acctId);
		double currentBalance=0;
	if(index>=0) {
		
		if(Transaction.getCount()<50) {
			try {
		currentBalance=accts[index].withdraw(amount);
		}catch (Exception e) {
			// TODO: handle exception
		}
			
		transactions[Transaction.getCount()]=new Transaction(new Timestamp(System.currentTimeMillis()),"debit",acctId,amount);
		
		}
		currentBalance=-1.0d;
	}
	return currentBalance;
	}
	
	
	
	public int searchForCustomer(Customer[] customers, int custId) {
		for(int i=0;i<customers.length&& customers[i]!=null;i++){
			System.out.println(customers[i].getCustId());
			if(customers[i].getCustId()==custId)
				return i;
			
		}
		return -1;
	}
	
	public void showCustomers(Customer[] customers) {
		for(int i=0;i<customers.length && customers[i]!=null;i++) {
			System.out.println(customers[i]);
		}
	}
	
	public void showAccounts(Account[] accounts) {
		for(int i=0;i<accounts.length && accounts[i]!=null;i++) {
			System.out.println(accounts[i]);
		}
	}
	
	public void showTransactions(Transaction[] transactions) {
		for(int i=0;i<transactions.length && transactions[i]!=null;i++) {
			System.out.println(transactions[i]);
		}
	}
	
}
