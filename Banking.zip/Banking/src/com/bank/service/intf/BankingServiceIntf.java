package com.bank.service.intf;

import java.sql.Timestamp;

import com.bank.beans.Account;
import com.bank.beans.Customer;
import com.bank.beans.Transaction;

public interface BankingServiceIntf {

	public Account openAccount(Customer cust, int acctId,String acctType,double amount,double withDrawLimit,Account[] accts,Transaction[] transactions);
	public double withdraw(int acctId,double amount,Account[] accts,Transaction[] transactions);
	public double deposit(int acctId, double amount,Account[] accts,Transaction[] transactions); 
	public int searchForCustomer(Customer[] customers, int custId);
	public void showCustomers(Customer[] customers);
	public void showAccounts(Account[] accounts);
	public void showTransactions(Transaction[] transactions) ;
}
