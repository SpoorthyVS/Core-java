package com.bank.beans;

public class Customer {

	private static int custCount=0;
	int custId;
	String custName;
	Address addr;
	String email;
	String panNum;
	
	
	
	@Override
	public String toString() {
		return  custId +"," +
				custName +"," +
				addr +"," +
				email+"," +
				panNum ;
	}
	public static int getCount() {
		return custCount;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
		if(custCount<10)
			custCount++;
	}
	
	public Customer(int custId, String custName, Address addr, String email, String panNum) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.addr = addr;
		this.email = email;
		this.panNum = panNum;
		if(custCount<10)
			custCount++;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPanNum() {
		return panNum;
	}

	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}

	
}
