package com.bank.beans;

import java.sql.Timestamp;

public class Transaction {

	private static int transCount=0;
	Timestamp transId;
	String transType;
	int acctId;
	double transAmount;
	
	
	
	
	@Override
	public String toString() {
		return  transId +"," +
				transType + "," +
				acctId + "," +
			    transAmount ;
	}
	public static int getCount() {
		return transCount;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
		if(transCount<50)
			transCount++;
	}
	
	
	public Transaction(Timestamp transId, String transType, int acctId, double transAmount) {
		super();
		this.transId = transId;
		this.transType = transType;
		this.acctId = acctId;
		this.transAmount = transAmount;
		if(transCount<50)
			transCount++;
	}
	
	
	public Timestamp getTransId() {
		return transId;
	}
	public void setTransId(Timestamp transId) {
		this.transId = transId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public int getAcctId() {
		return acctId;
	}
	public void setAcctId(int acctId) {
		this.acctId = acctId;
	}
	public double getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}
	
	
}
